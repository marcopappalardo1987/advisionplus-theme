<?php

namespace tpCore\cssGenerator;

require_once get_template_directory() . '/inc/tp-classes/tp-core.php';
use tpCore\themeplus;

/**
 * This class generates all the css code for the Header dynamically.
 */
class headerCssGenerator{

    /**
	 * Redux options
	 * 
	 * @var object
	 */
    protected $option;
    
    /**
	 * Theme Plus Core
	 * 
	 * @var object
	 */
	protected $theme;

    public function __construct(){

		/**
		 * Theme Plus Options from Redux
		 */
        $this->option = $GLOBALS["themeplus_option"];
        
        /**
         * Theme Plus Core
         */
        $this->theme = new themeplus;
        
        $this->header_style_options();
        $this->header_css_generation();
    }


    protected $css_top_header;

    /**
     * This method sets all the conditions to generate the css dynamically
     *
     * @return void
     */
    public function header_style_options(){
        $this->css_top_header = null;
        
        //Global site width
        if(isset($this->option["tp-site-width"])){
            $this->css_top_header .= '#tp-top-header, .tp-logo, .tp-main, .site-info, #site-navigation, #tp-header-logo, .tp-entry-content, .tp-entry-footer {width: 100%; max-width: '.$this->option["tp-site-width"].'; margin: auto;';
            if($this->option["tp-site-padding"]["padding-right"] == '' || $this->option["tp-site-padding"]["padding-left"] == ''){
                $this->css_top_header .= 'padding: 0px 15px;';
            }
            $this->css_top_header .= '}';
        }

        //Top Header Background
        if(isset($this->option["tp-top-header-background"])){
            $this->css_top_header .= $this->theme->background_color_css($this->option["tp-top-header-background"]["background-color"], $this->option["tp-top-header-background-opacity"], '.tp-site-header #tp-top-header-container');
        }

        //Logo Align
        if(isset($this->option["tp-logo-align"])){
            if($this->option["tp-logo-align"]=='right'){
                $this->css_top_header .= '.tp-logo-default {float: right;}';
            }
            elseif($this->option["tp-logo-align"]=='center'){
                $this->css_top_header .= '.tp-logo-default {max-width: max-content; margin: auto;}';
            }
            else{}
        }

        //Primary Menu Height 
        if(isset($this->option["tp-primary-menu-height"])){
            $this->css_top_header .= '#site-navigation > div {height: '.$this->option["tp-primary-menu-height"].';'; 
                if($this->option["tp-primary-menu-vertical-align"]){
                    $this->css_top_header .= 'display: table-cell; vertical-align: '.$this->option["tp-primary-menu-vertical-align"].';}';
                }               
        }

        //Primary Menu Padding Right
        if(isset($this->option["tp-primary-menu-right-padding"])){
            $this->css_top_header .= '#primary-menu li {padding-right: '.$this->option["tp-primary-menu-right-padding"].'px;}';
            $this->css_top_header .= '#primary-menu li:last-child {padding-right: 0px;}';
        }

        //Top Header Menu Padding Right
        if(isset($this->option["tp-top-header-menu-right-padding"])){
            $this->css_top_header .= '#top-header-menu li {padding-right: '.$this->option["tp-top-header-menu-right-padding"].'px;}';
            $this->css_top_header .= '#top-header-menu li:last-child {padding-right: 0px;}';
        }
        
        return($this->css_top_header);
    }


    /**
     * Url of the file where the css code will be written.
     *
     * @var string
     */
    public $options_header_css;

    /**
     * Code css generated.
     *
     * @var mixed
     */
    public $css;

    /**
     * File where the css code is inserted.
     *
     * @var resource
     */
    public $file;

    /**
     * This method writes a css file for the theme header
     *
     * @return void
     */
    public function header_css_generation(){
        $this->options_header_css = get_template_directory() . '/assets/public/css/options-header.css';
        $this->css = $this->header_style_options();

        $this->file = fopen($this->options_header_css,"w+");
        return fwrite($this->file,$this->css);
        fclose($this->file);
    }
    
}