<?php

if(!function_exists('header_style_options')){
    function header_style_options(){

        global $themeplus;
                
        if( $themeplus["layout-type"] == '0' ){
            $css_top_header = '.tp-site-header > *, .tp-menu ul, #tp-top-header {width: '.$themeplus["content-width"]["width"].'}';
        }
        
        //$WP_Filesystem_SSH2 = new WP_Filesystem_SSH2();
        //$WP_Filesystem_SSH2->put_contents->put_contents( get_template_directory_uri() . '/assets/public/css/options-header.css', $css_top_header, FS_CHMOD_FILE);
        
        return($css_top_header);
    }
}

function risultato(){
    $options_header_css = get_template_directory() . '/assets/public/css/options-header.css';
    $css = header_style_options();

    $file = fopen($options_header_css,"w+");
    echo fwrite($file,$css);
    fclose($file);
    }
risultato();