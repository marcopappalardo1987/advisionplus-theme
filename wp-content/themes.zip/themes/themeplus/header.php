<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Theme_Plus
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class('tp-body'); ?>>
<?php wp_body_open(); ?>
<div id="page" class="site tp-site">
	<a class="tp-links skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'themeplus' ); ?></a>


	<header id="masthead" class="tp-site-header tp-site-header-1">
		<!-- TOP HEADER -->
		<div id="tp-top-header-container" class="top-header-container">
			<div id="tp-top-header" class="top-header row">
				<div id="tp-top-header-left" class="col-md-6">
					<div id="tp-header-email" class="header-email">loremipsum@gmail.com</div>
					<div id="tp-header-phone" class="header-phone">392392392</div>
				</div>
				<div id="tp-top-header-right" class="col-md-6">
					<div id="tp-top-header-menu" class="top-header-menu">menu - chi siamo - contatti</div>
				</div>
			</div>
		</div>
		<!-- LOGO HEADER -->
		<div id="tp-header-logo" class="row">
			<div class="tp-logo col-md-12">
			<?php 
			the_custom_logo();
			
			if ( is_front_page() && is_home() ) :
				?>
				<h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
				<?php
			else :
				?>
				<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
				<?php
			endif;

			?>
			</div>
		</div>

		<!-- MAIN NAVIGATION HEADER -->
		<div id="tp-header-logo" class="row">
			<nav id="site-navigation" class="main-navigation col-md-12">
				<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'themeplus' ); ?></button>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'menu-1',
						'menu_id'        => 'primary-menu',
						'menu_class'	 => 'tp-primary-menu',
					)
				);
				?>
			</nav>
		</div>

		
	</header>

